import javax.script.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*; 
public class FileUploadEng  {  
    public static void main(String[] args) {          
        ActionFrame1 test = new ActionFrame1();         
    }
}  
  
class ActionFrame1 implements ActionListener{  
      
    JButton fileupload=new JButton("Upload");  
    GridLayout layout =new GridLayout(2,0);
    JFrame myFrame = new JFrame();  
    JButton buttonNext=new JButton("Next");
    JPanel framePanel=new JPanel(layout);
    static ArrayList<String> expression = new ArrayList<String>();
    public ActionFrame1(){  
    	fileupload.addActionListener(this);   
    	 myFrame.add(framePanel);
        myFrame.setVisible(false);  
        myFrame.setSize(500, 500);  
        JPanel myPanel = new JPanel();     
    }     
    public void actionPerformed(ActionEvent e) { 
        if(e.getSource()==fileupload){
        	try {
        	TextArea area=null; // �����ı���
        	String path = null;
	    	JFileChooser fc = new JFileChooser();
	    	fc.setDialogTitle("Please select the file to upload...");
	    	fc.setApproveButtonText("Submit");
	    	fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
	    	if (JFileChooser.APPROVE_OPTION == fc.showOpenDialog(fc)) {
	    	    path=fc.getSelectedFile().getPath();
	    	    System.out.println(path);
	    	    if(path.substring(path.length()-3,path.length()).equals("txt")) {
	    	    	expression = readTxtFile(path);
					//myFrame.setVisible(true);
					
	    	    	MakeExpression.arith=expression.get(0);
	    	    	MakeExpression gui=new MakeExpression();
					gui=new MakeExpression();
					area.setVisible(true);
					area.setText(null);
					
	    	    }
	    	}else{
	    		area.setText("Please upload the *.txt document!");
			}
        	}catch (Exception e2) {
				e2.printStackTrace();
			}
        }     
          
    }  
    
	// ��ȡ�ļ�����
	public static ArrayList<String> readTxtFile(String filePath) {
		try {
			String encoding = "utf-8";
			File file = new File(filePath);
			
			if (file.isFile() && file.exists()) { // �ж��ļ��Ƿ����
				InputStreamReader read = new InputStreamReader(new FileInputStream(file), encoding);// ���ǵ������ʽ
				BufferedReader bufferedReader = new BufferedReader(read);
				String lineTxt = null;
				while ((lineTxt = bufferedReader.readLine()) != null) {
					expression.add(lineTxt);
				}
				read.close();
			}

			return expression;
		} catch (Exception e) {
			System.out.println("Error reading file content");
			e.printStackTrace();
			return null;
		}
	}
	
	// ����ÿ��ʽ�ӵĽ��
	static ScriptEngine jse = new ScriptEngineManager().getEngineByName("JavaScript");

	public static ArrayList<String> calculate(ArrayList<String> list) {
		ArrayList<String> calExpression = new ArrayList<String>();
		for (String ex : list) {
			try {
				String x=jse.eval(ex).toString();
				int x2=(int)Double.parseDouble(x);
				ex = ex + "=" + x2;
				calExpression.add(ex);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return calExpression;
	}
	public JButton getButton() {
		return fileupload;
	}
	public void setArith() {
		
	}
  public String getResult(String ex) {
	  String x="";
	  ex=ex.replaceAll("��", "/");
	  try {
		x=jse.eval(ex).toString();
	} catch (ScriptException e) {
		e.printStackTrace();
	}
	  return x;
  } 
}  


