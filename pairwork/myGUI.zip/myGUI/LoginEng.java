import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class LoginEng {
	public LoginEng() 
	{
		JFrame f=new JFrame();
		f.setTitle("Four arithmetic answering system for primary school students");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		f.setVisible(true);
		//���ô��ڵĴ�С��λ��
		f.setSize(600, 600);
		f.setLocation(300,300);
		
		Container con=f.getContentPane();//����һ������	
		con.setLayout(new GridLayout(7,1));
		
		JPanel pan1 =new JPanel();
		JLabel title=new JLabel("Welcome four arithmetic answering system for landing pupils");
		title.setFont(new Font("����",Font.BOLD, 20));
		pan1.add(title);
		con.add(pan1);
		//����һ���µİ�	  
		JPanel pan2 = new JPanel();
		JPanel pan3 = new JPanel();
		JPanel pan4 = new JPanel();
		JPanel pan5 = new JPanel();
		
		con.add(pan2);
		con.add(pan3);	
		con.add(pan4);
		con.add(pan5);
		f.setVisible(true);
		JLabel name=new JLabel("Username");
		pan2.add(name);
		TextField tf_name=new TextField(20);
		pan2.add(tf_name);
		
		JLabel pass = new JLabel("Password");
		pan3.add(pass);
		TextField password=new TextField(20);
		password.setEchoChar('*');
		pan3.add(password);
		
		JButton b_log=new JButton("Login");  
		b_log.addActionListener(new ActionListener() {  
		    public void actionPerformed(ActionEvent e) {  
		        //��ȡ�û��������룬����У��  
		        String myUsername=tf_name.getText(); 
				String myPassword=password.getText();  
		        if(myUsername.equals("1")&& myPassword.equals("1")){  
		            f.dispose();
		            OrderGUIEng frame = new OrderGUIEng();
		    		frame.pack();
		    		frame.setSize(550, 350);
		    		frame.setTitle("Order problems");
		    		frame.setLocationRelativeTo(null);
		    		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		    		frame.setVisible(true);
		            
		        }
		        else{  
		            JOptionPane.showMessageDialog(null, "Account or password error!");  
		            tf_name.setText( "");  
		            password.setText( "");  
		        }  
		          
		    }  
		});  
		pan4.add(b_log); 
		
		JButton b_exit=new JButton("Quit");  	 
		b_exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				 f.setVisible(false);//���ش���
				 System.exit(0);//�˳�����
			}		
		});
		pan5.add(b_exit);  
	}
}