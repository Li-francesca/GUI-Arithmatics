import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.script.*;
import javax.swing.*;

public class OrderGUI extends JFrame {

	private JTextField n = new JTextField();
	private JTextField o = new JTextField();
	private JTextField m1 = new JTextField();
	private JTextField m2 = new JTextField();
	private int a = 0, b = 0, c = 0;
	private JTextField sum2 = new JTextField();
	int rightSum = 0;
	TypeExpression typeexp = new TypeExpression();
	private JPanel panel1 = new JPanel();
	private JLabel label = new JLabel();
	JTextField text = new JTextField(10);
	ArrayList<String> list = new ArrayList<String>();

	private JButton jbtStart = new JButton("��ʼ����");
	private JButton fileupload = new JButton("�ϴ��ļ�");
	private JButton Again=new JButton("����һ��");     //����һ��
	private JCheckBox Mul = new JCheckBox("���г˳�"); // ��ѡ��
	private JCheckBox Bra = new JCheckBox("��������");
	  
	public OrderGUI() {
		fileupload=new ActionFrame().getButton();
		JPanel p1 = new JPanel(new GridLayout(0, 2));
		JPanel p3 = new JPanel(new GridLayout(0, 2));
		p1.add(new JLabel("��������Ŀ��[1,1000]: "));
		p1.add(n);
		p1.add(new JLabel("���������޷�Χ[1,100]: "));
		p1.add(m1);
		p1.add(new JLabel("���������޷�Χ[50,1000]:  "));
		p1.add(m2);
		p1.add(new JLabel("���������������[1,10]: "));
		p1.add(o);
		p3.add(Bra);
		p3.add(Mul);
		JPanel p2 = new JPanel();
		p2.add(fileupload);
		
		p2.add(jbtStart);
		add(p1, BorderLayout.CENTER);
		add(p2, BorderLayout.SOUTH);
		add(p3, BorderLayout.EAST);
		ButtonListener listener = new ButtonListener();
		jbtStart.addActionListener(listener);
		Mul.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c = 1; // �Ƿ��г˳�
			}
		});
		Bra.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				b = 1; // �Ƿ�������
			}
		});
	}
	
	class ButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			TypeExpression typeexp = new TypeExpression();
			int ns = Integer.parseInt(n.getText());
			int os = Integer.parseInt(o.getText());
			int m1s = Integer.parseInt(m1.getText());
			int m2s = Integer.parseInt(m2.getText());
			if (e.getSource() == jbtStart) {
				long isfirst=System.currentTimeMillis();
				JFrame frame2 = new JFrame();
				frame2.setTitle("�������");
				frame2.setSize(400,300);
				frame2.setLocationRelativeTo(null);
				frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame2.setVisible(true);
				if (c ==0 && b == 0) {
					String answer = TypeExpression.compute1(ns, os, m1s, m2s);
					label.setText(answer);
				}
				if (c != 1 && b == 1) {
					String answer = TypeExpression.compute2(ns, os, m1s, m2s);
					label.setText(answer);
				}
				if (c == 1 && b != 1) {
					String answer = TypeExpression.compute3(ns, os, m1s, m2s);
					label.setText(answer);
				}
				if (c == 1 && b == 1) {
					String answer = TypeExpression.compute4(ns, os, m1s, m2s);
					label.setText(answer);
				}
				
				panel1.add(label);
				JPanel panel2 = new JPanel();
				panel2.add(new JLabel("������𰸣�"));
				panel2.add(text);
				JButton buttonSubmit = new JButton("�鿴���");
				JButton buttonNext = new JButton("��һ��");
				JPanel panel3 = new JPanel();
				panel3.add(buttonNext);
				panel3.add(buttonSubmit);

				frame2.add(panel1, BorderLayout.NORTH);
				frame2.add(panel2, BorderLayout.CENTER);
				frame2.add(panel3, BorderLayout.SOUTH);
				frame2.setSize(1000, 1000);
				frame2.setLocationRelativeTo(null);
				frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame2.setVisible(true);

				buttonSubmit.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						frame2.dispose();
						int size = list.size();
						int errorSum = size - rightSum;
						JFrame resultFrame = new JFrame();
						JPanel panelagain = new JPanel();
						//panelagain.add(Again);
						resultFrame.add(panelagain, BorderLayout.SOUTH);
						resultFrame.setTitle("�������");
						resultFrame.setSize(600, 600);
						resultFrame.setLocationRelativeTo(null);
						resultFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						resultFrame.setVisible(true);
						JPanel panel = new JPanel();
						Font font = new Font(Font.DIALOG, Font.PLAIN, 20);
						long isend=System.currentTimeMillis();
						long time=isend-isfirst;
						panel.add(new JLabel("���������� " + size + " " + "��ȷ����" + rightSum + " ��ʱ:"+time/1000+"��"));
						panel.add(new JLabel("��ȷ�ʣ� " + (rightSum*100/size)+"%"));
						setLayout(new GridLayout(100, 1, 5, 5));
							for (int i = 0; i < size; i++) {
								panel.add(new JLabel(list.get(i)));
							}
						
						resultFrame.add(panel);
						/*Again.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								new OrderGUI();
								resultFrame.dispose();
							}
							});
						}*/
					}
				});
				
				
				fileupload.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
			        	try {
			        	TextArea area=null; // �����ı���
			        	String path = null;
				    	JFileChooser fc = new JFileChooser();
				    	fc.setDialogTitle("��ѡ��Ҫ�ϴ����ļ�...");
				    	fc.setApproveButtonText("ȷ��");
				    	fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
				    	if (JFileChooser.APPROVE_OPTION == fc.showOpenDialog(fc)) {
				    	    path=fc.getSelectedFile().getPath();
				    	    System.out.println(path);
				    	    if(path.substring(path.length()-3,path.length()).equals("txt")) {
								ArrayList<String> t = readTxtFile(path);
								area.setVisible(true);
								area.setText(null);
								for (int i = 0; i < t.size(); i++) {
									area.append(t.get(i) + "\n");
								}
				    	    }
				    	}else{
				    		area.setText("���ϴ�*.txt�ĵ���");
						}
			        	}catch (Exception e2) {
							// TODO: handle exception
							e2.printStackTrace();
						}
			        }

					// ��ȡ�ļ�����
					public ArrayList<String> readTxtFile(String filePath) {
						try {
							String encoding = "utf-8";
							File file = new File(filePath);
							ArrayList<String> expression = new ArrayList<String>();
							if (file.isFile() && file.exists()) { // �ж��ļ��Ƿ����
								InputStreamReader read = new InputStreamReader(new FileInputStream(file), encoding);// ���ǵ������ʽ
								BufferedReader bufferedReader = new BufferedReader(read);
								String lineTxt = null;
								while ((lineTxt = bufferedReader.readLine()) != null) {
									expression.add(lineTxt);
								}
								read.close();
							}

							return expression;
						} catch (Exception e) {
							System.out.println("��ȡ�ļ����ݳ���");
							e.printStackTrace();
							return null;
						}
					}				
				});
				
				buttonNext.addActionListener(new ActionListener() {// ����ʱ�������
					public void actionPerformed(ActionEvent e) {
						
						String question = label.getText();
						int count = 0;
						double sum2 = Double.parseDouble(text.getText());
						if (count < ns) {
							String ifRight = "";
							if (typeexp.sum == sum2) {
								ifRight = "��ȷ";
								rightSum++;
								count++;
							} else {
								ifRight = "����";
								count++;
							}
							String message = question + "�� " + "��Ĵ𰸣�" + sum2 + "�� " + "��ȷ�𰸣� " + typeexp.sum + "�� ״̬�� "
									+ ifRight;
							
							list.add(message);
							text.setText("");
							if (c ==0 && b == 0) {
								String answer = TypeExpression.compute1(ns, os, m1s, m2s);
								label.setText(answer);
							}
							if (c != 1 && b == 1) {
								String answer = TypeExpression.compute2(ns, os, m1s, m2s);
								label.setText(answer);
							}
							if (c == 1 && b != 1) {
								String answer = TypeExpression.compute3(ns, os, m1s, m2s);
								label.setText(answer);
							}
							if (c == 1 && b == 1) {
								String answer = TypeExpression.compute4(ns, os, m1s, m2s);
								label.setText(answer);
							}
						}
					}
				});
				
			}
		}
	}
}