import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import javax.script.*;
import javax.swing.*;

public class ChooseLanguage extends JFrame {
	
	public ChooseLanguage() {
		
		JPanel p = new JPanel();
		JFrame f=new JFrame();
		f.setTitle("ѡ������");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		f.setVisible(true);
		f.setSize(400, 300);
		f.setLocation(300,300);
		
		Container con=f.getContentPane();//����һ������	
		con.setLayout(new GridLayout(7,1));
		con.add(p);

		
		JButton jbtChinese=new JButton("����");  
		jbtChinese.addActionListener(new ActionListener() {  
		    public void actionPerformed(ActionEvent e) {  
		            new Login();
		            f.dispose();
		        }
		});  
		p.add(jbtChinese);
		
		JButton jbtEnglish=new JButton("English");  
		jbtEnglish.addActionListener(new ActionListener() {  
		    public void actionPerformed(ActionEvent e) {  
		            new LoginEng();
		            f.dispose();
		        }
		});  
		p.add(jbtEnglish);
		f.setVisible(true);
	}
}