import javax.swing.*;
import java.util.*;
public class TypeExpression {
        static  double sum = 0;
        static int result;
        static ArrayList<String> list=new ArrayList<String>();
        static public String compute4(int n,int o,int m1,int m2)
        {
            String arr = null;
            int sum=0;
            int coun=0;
            for (;;)
            {
                if(coun==n)break;
                char[]operate = {'+','-','*','��'};

                Random random = new Random();
                int th=o;
                int s=random.nextInt(4);
                int a=random.nextInt(m2);
                int b=random.nextInt(m2);

                if(operate[s]=='+')
                {

                    sum=a+b;
                }
                if(operate[s]=='*')
                {

                    sum=a*b;
                }
                if(operate[s]=='-')
                {

                    sum=a-b;
                }
                if(operate[s]=='��')
                {
                    if(b==0)b++;
                    while(a%b!=0)
                    {
                            a=random.nextInt(m2);
                            b=random.nextInt(m2)+1;
                    }
                    sum=a/b;
                }
                arr=a+""+operate[s]+""+b;

                for(int i=1;i<th;i++){
                    int s1=random.nextInt(4);
                    int b1=random.nextInt(m2);
                    a=sum;
                    if (operate[s1]=='+')
                    {

                        arr=arr+operate[s1]+b1;
                        sum=a+b1;
                    }
                    if (operate[s1]=='*')
                    {

                        if(operate[s]=='-'||operate[s]=='+')
                        {
                            arr="("+arr+")"+operate[s1]+b1;
                        }
                        else
                        {
                            arr=arr+operate[s1]+b1;
                        }
                        sum=a*b1;
                    }
                    if(operate[s1]=='-')
                    {

                        arr=arr+""+operate[s1]+b1;
                    sum=a-b1;
                    }
                    if(operate[s1]=='��')
                    {   if(b1==0)b1++;
                        while(a%b1!=0)
                        {

                            b1=random.nextInt(m2)+1;
                        }
                        if(operate[s]=='-'||operate[s]=='+')
                        {
                            arr="("+arr+")"+operate[s1]+b1;
                        }
                        else
                        {
                            arr=arr+operate[s1]+b1;
                        }
                        sum=a/b1;
                    }

                    s=s1;
                }
                if(sum<=m2&&sum>=m1||sum<=-m1&&sum>=-m2)
                {
                    //System.out.println(arr+"=");
                    coun++;
                }
                list.add(arr);
            }
            TypeExpression.sum=sum;
            return arr+"="+"?";
        }

    static public String compute3(int n,int o,int m1,int m2) {
        String arr = "";

        int sum=0;
        int coun=0;
        for (;;)
        {
            if(coun==n)break;
            char[] oper = { '+', '-', '*', '��' };
            Random random = new Random();
            int th=o;
            int s = random.nextInt(4);
            int a=random.nextInt(m2);
            int b=random.nextInt(m2);

            if(oper[s]=='+')
            {

                sum=a+b;
            }
            if(oper[s]=='*')
            {

                sum=a*b;
            }
            if(oper[s]=='-')
            {

                sum=a-b;
            }
            if(oper[s]=='��')
            {
            	if(b==0)b++;
                while(a%b!=0)
                {
                        a=random.nextInt(m2);
                        b=random.nextInt(m2)+1;
                }
                sum=a/b;
            }
            arr = a + "" + oper[s] + "" + b;
            //System.out.print(arr);

            for (int i = 1; i < th; i++) {
                int s1 = random.nextInt(4);
                int b1=random.nextInt(m2);
                a = sum;

                if(oper[s1]=='-')
                {

                    arr=arr+""+oper[s1]+b1;
                sum=a-b1;
                }

                if (oper[s1] == '��') {
                	if(b1==0)b1++;
                    while(a%b1!=0)
                    {
                        b1=random.nextInt(m2)+1;
                    }
                    sum = a / b1;
                }
                if (oper[s1]=='+')
                {

                    arr=arr+oper[s1]+b1;
                    sum=a+b1;
                }
                if (oper[s1] == '*') {

                    sum = a * b1;
                }


                //System.out.print(arr);
            }

            if(sum<=m2&&sum>=m1||sum<=-m1&&sum>=-m2)
            {
                //System.out.println(arr+"=");
                coun++;
            }
            list.add(arr);
        }
        TypeExpression.sum=sum;
        return arr+"="+"?";
    }
    static public String compute2(int n,int o,int m1,int m2){
        String arr = "";
        int sum=0;
        int coun=0;
        for (;;)
        {
            if(coun==n)break;
            char[]operate = {'+','-'};
            Random random = new Random();
            int th=o;
            int s=random.nextInt(2);
            int a=random.nextInt(m2-m1+1)+m1;
            int b=random.nextInt(m2-m1+1)+m1;
            if(operate[s]=='+')
            {

                sum=a+b;
            }
            if(operate[s]=='-')
            {

                sum=a-b;
            }
            arr=a+""+operate[s]+""+b;

            for(int i=1;i<th;i++)
            {
                int s1=random.nextInt(2);
                int b1=random.nextInt(m2);
                a=sum;
                if (operate[s1]=='+')
                {

                    arr=arr+operate[s1]+b1;
                    sum=a+b1;
                }
                if(operate[s1]=='-')
                {

                 if(operate[s]=='+')
                 {
                   arr="("+arr+")"+operate[s1]+b1;
                 }
                 else
                 {
                   arr=arr+operate[s1]+b1;
                 }
                 sum=a-b1;

                }
            s=s1;
          }

            if(sum<=m2&&sum>=m1||sum<=-m1&&sum>=-m2)
            {
                //System.out.println("haha="+arr+"=");
                coun++;
            }
            list.add(arr);
        }
        TypeExpression.sum=sum;
        return arr+"="+"?";
    }


        static public String compute1(int n,int o,int m1,int m2) {
            String arr = null;
            int sum=0;
            int coun=0;
            for (;;)
            {
                if(coun==n)break;
                char[] oper = { '+', '-' };
                Random random = new Random();

                int th=o;
                int s = random.nextInt(2);
                int a=random.nextInt(m2-m1+1)+m1;
                int b=random.nextInt(m2-m1+1)+m1;


                if(oper[s]=='+')
                {

                    sum=a+b;
                }

                if(oper[s]=='-')
                {

                    sum=a-b;
                }

                arr = a + "" + oper[s] + "" + b;
                //System.out.print(arr);

                for (int i = 1; i < th; i++) {
                    int s1 = random.nextInt(2);
                    int b1=random.nextInt(m2-m1+1)+m1;
                    a = sum;

                    if(oper[s1]=='-')
                    {

                        arr=arr+""+oper[s1]+b1;
                    sum=a-b1;
                    }


                    if (oper[s1]=='+')
                    {

                        arr=arr+oper[s1]+b1;
                        sum=a+b1;
                    }
                }

                if(sum<=m2&&sum>=m1||sum<=-m1&&sum>=-m2)
                {
                    coun++;
                }
                list.add(arr);
            }
            TypeExpression.sum=sum;
            System.out.println(sum);
            return arr+"="+"?";
        }
}
