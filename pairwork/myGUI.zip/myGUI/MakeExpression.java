import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

import org.omg.CosNaming.NamingContextExtPackage.AddressHelper;

public class MakeExpression extends JFrame{
	static String arith="";
	JLabel label=new JLabel(arith);
	JTextField text = new JTextField(10);
	ArrayList<String> resultList=new ArrayList<String>();
	int count=1;
	int rightsum=0;
public MakeExpression() {
	JFrame frame2 = new JFrame();
	frame2.setTitle("�������");
	frame2.setSize(500, 500);
	frame2.setLocationRelativeTo(null);
	frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame2.setVisible(true);
	JPanel panel1=new JPanel();
	
	panel1.add(label);
	JPanel panel2 = new JPanel();
	panel2.add(new JLabel("������𰸣�"));
	panel2.add(text);
	JButton buttonSubmit = new JButton("�ύ��");
	buttonSubmit.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			int size = resultList.size();
			int errorSum = size - rightsum;
			JFrame resultFrame = new JFrame();
			resultFrame.setTitle("������");
			resultFrame.setSize(350, 500);
			resultFrame.setLocationRelativeTo(null);
			resultFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			resultFrame.setVisible(true);
			JPanel panel = new JPanel();
			//panel.setLayout(new GridLayout(100, 1, 5, 5));
			Font font = new Font(Font.DIALOG, Font.PLAIN, 20);
			panel.add(new JLabel("���������� " + size + " " + "��ȷ����" + rightsum));
			setLayout(new GridLayout(100, 1, 5, 5));
			//while (size < ns) {
				for (int i = 0; i < size; i++) {
					panel.add(new JLabel(resultList.get(i)));
				}
				//resultFrame.add(panel);
			//}
			resultFrame.add(panel);
		}
		
	});
	JButton buttonNext = new JButton("��һ��");
	nextListener l=new nextListener();
	buttonNext.addActionListener(l);
	JPanel panel3 = new JPanel();
	panel3.add(buttonNext);
	panel3.add(buttonSubmit);

	frame2.add(panel1, BorderLayout.NORTH);
	frame2.add(panel2, BorderLayout.CENTER);
	frame2.add(panel3, BorderLayout.SOUTH);
	frame2.setSize(500, 500);
	frame2.setLocationRelativeTo(null);
	frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame2.setVisible(true);
}

class nextListener implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
		
		String message="";
		int i=ActionFrame.expression.size();
		arith=ActionFrame.expression.get(count);
		String laString =label.getText();
		String trueResult=new ActionFrame().getResult(laString);
		//System .out.println(trueResult);
		label.setText(arith);
		String result=text.getText();
		text.setText("");
		System .out.println(result);
		if(result.equals(trueResult)) {
			rightsum++;
			message ="��Ŀ��"+laString+" ״̬����ȷ ";
		}else {
			message ="��Ŀ��"+laString+" ״̬������ ��ȷ���ǣ� "+trueResult;
		}
		resultList.add(message);
		count++;
		if(count==i) {
			int size = resultList.size();
			int errorSum = size - rightsum;
			JFrame resultFrame = new JFrame();
			resultFrame.setTitle("������");
			resultFrame.setSize(500, 500);
			resultFrame.setLocationRelativeTo(null);
			resultFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			resultFrame.setVisible(true);
			JPanel panel = new JPanel();
			Font font = new Font(Font.DIALOG, Font.PLAIN, 20);
			panel.add(new JLabel("���������� " + size + " " + "��ȷ����" + rightsum));
			setLayout(new GridLayout(100, 1, 5, 5));
				for (int k = 0; k < size; k++) {
					panel.add(new JLabel(resultList.get(k)));
				}
			resultFrame.add(panel);
		}
	}
	
}
}

